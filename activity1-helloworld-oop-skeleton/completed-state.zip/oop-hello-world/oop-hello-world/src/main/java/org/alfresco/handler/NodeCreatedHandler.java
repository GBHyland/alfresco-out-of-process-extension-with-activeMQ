package org.alfresco.handler;

import org.alfresco.event.sdk.handling.handler.OnNodeCreatedEventHandler;
import org.alfresco.repo.event.v1.model.*;
import org.springframework.stereotype.Component;

@Component
public class NodeCreatedHandler implements OnNodeCreatedEventHandler {
    @Override
    public void handleEvent(RepoEvent<DataAttributes<Resource>> event) {
        final NodeResource nodeResource = (NodeResource) event.getData().getResource();
        System.out.println("Hello World! "+nodeResource.getName());
    }
}
