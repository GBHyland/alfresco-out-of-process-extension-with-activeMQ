package org.alfresco;

import org.alfresco.event.sdk.handling.filter.EventTypeFilter;
import org.alfresco.event.sdk.handling.filter.NodeTypeFilter;
import org.alfresco.event.sdk.integration.EventChannels;
import org.alfresco.event.sdk.integration.filter.IntegrationEventFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.context.annotation.Bean;


/**
 * Hello world!
 *
 */

@SpringBootApplication
@EnableAutoConfiguration(exclude={SecurityAutoConfiguration.class})

public class App 
{
    private static final Logger LOGGER = LoggerFactory.getLogger(App.class);

    public static void main( String[] args )
    {
        SpringApplication.run(App.class, args);
    }

    @Bean
    public IntegrationFlow logTheCreationOfNodesOfTypeContent() {
        return IntegrationFlow.from(EventChannels.MAIN)
                .filter(IntegrationEventFilter.of(EventTypeFilter.NODE_CREATED
                        .and(NodeTypeFilter.of("cm:content"))))
                .handle(t -> LOGGER.info("A new node of type cm:content has been created! - Event: {}", t.getPayload().toString()))
                .get();
    }

}
