package org.alfresco.handler;

import org.alfresco.core.handler.CommentsApi;
import org.alfresco.core.model.CommentBody;
import org.alfresco.event.sdk.handling.filter.EventFilter;
import org.alfresco.event.sdk.handling.filter.IsFileFilter;
import org.alfresco.event.sdk.handling.handler.OnNodeUpdatedEventHandler;
import org.alfresco.repo.event.v1.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.Set;

@Component
public class NodeUpdatedHandler implements OnNodeUpdatedEventHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(NodeUpdatedHandler.class);
    @Autowired
    CommentsApi commentsApi;

    @Override
    public void handleEvent(RepoEvent<DataAttributes<Resource>> event) {
        final NodeResource nodeResource = (NodeResource) event.getData().getResource();

        //System.out.println("\n\n** Doc updated someone other than creator: "+nodeResource.toString());
        //System.out.println("\n===== Resource Before: "+ event.getData().getResourceBefore());
        LOGGER.info("\n\n ** DATA: "+event.getData());

        if (((NodeResource) event.getData().getResourceBefore()).getContent() != null) {
            System.out.println("This content has been modified. ");
            if (!nodeResource.getModifiedByUser().getId().equals(nodeResource.getCreatedByUser().getId()))
            {
                System.out.println("This doc was modified by someone other than creator!");
                CommentBody commentBody = new CommentBody();
                commentBody.setContent("Edited by user: "+nodeResource.getModifiedByUser().getId());
                commentsApi.createComment(nodeResource.getId(), commentBody, null);
            }
        }

    }

    @Override
    public EventFilter getEventFilter() {
        return IsFileFilter.get();
    }

    // https://github.com/Alfresco/alfresco-java-sdk/blob/develop/samples/event-api-handlers/src/main/java/org/alfresco/sdk/sample/event/handler/MultipleEventTypeHandler.java
    @Override
    public Set<EventType> getHandledEventTypes() {
        return OnNodeUpdatedEventHandler.super.getHandledEventTypes();
    }
}
